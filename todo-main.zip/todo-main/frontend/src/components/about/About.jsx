import React from "react";
import "./about.css";
const About = () => {
  return (
    <div className="about d-flex justify-content-center align-items-center">
      <div className="container">
        <div className="d-flex">
          <h1>About Us</h1>
        </div>

        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa, ad? Non
          animi facere vero nostrum qui repudiandae, nihil recusandae amet
          quisquam dicta quos, praesentium ipsam libero distinctio ea, atque
          deleniti? Lorem ipsum dolor sit amet, consectetur adipisicing elit.
          Distinctio rerum modi, velit iusto fuga necessitatibus dicta molestias
          facere numquam natus quibusdam, error sunt. Eveniet iure modi est
          recusandae, quasi ut?Lorem ipsum dolor sit amet consectetur
          adipisicing elit. Amet, quae. Atque accusamus explicabo perferendis at
          illum laudantium eos velit cumque vero, odio illo ipsum hic earum
          alias cupiditate minima a! <br />
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa, ad? Non
          animi facere vero nostrum qui repudiandae, nihil recusandae amet
          quisquam dicta quos, praesentium ipsam libero distinctio ea, atque
          deleniti? Lorem ipsum dolor sit amet, consectetur adipisicing elit.
          Distinctio rerum modi, velit iusto fuga necessitatibus dicta molestias
          facere numquam natus quibusdam, error sunt. Eveniet iure modi est
          recusandae, quasi ut?Lorem ipsum dolor sit amet consectetur
          adipisicing elit. Amet, quae. Atque accusamus explicabo perferendis at
          illum laudantium eos velit cumque vero, odio illo ipsum hic earum
          alias cupiditate minima a!
        </p>
      </div>
    </div>
  );
};

export default About;
